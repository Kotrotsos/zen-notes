#!/bin/bash

echo "=== Zen Notes Startup Script ==="
echo "Node version: $(node --version)"
echo "NPM version: $(npm --version)"
echo "Current directory: $(pwd)"

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm ci --production=false
else
    echo "node_modules exists, skipping install"
fi

# Build the application if .next doesn't exist
if [ ! -d ".next" ]; then
    echo "Building application..."
    npm run build
else
    echo ".next exists, skipping build"
fi

# Start the application
echo "Starting Next.js application..."
npm start
